﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Classes
{
    public class Img
    {
        #region khai bao cac thuoc tinh anh xa
        public int ID { get; set; }
        public string Ten { get; set; }
        public string HinhAnh { get; set; }
        public Img() { }
        #endregion
    }
}
